# Astralclef

Phased automation bot for **Create: Astral** on Fabric 1.18.2.

## Goal

Win condition: complete **FTB Quests Chapter 6 — Astral Singularity**.

## Phases

| Phase | Focus |
|-------|--------|
| Ch0.5–1 | Getting started (early Create + Astral basics) |
| Moon | Lunar progression |
| Mars | Martian progression |
| Mercury | Mercurial progression |
| Singularity | Astral Singularity (endgame win) |

## Build

```bash
./gradlew build
```

Requires JDK 17+.

## License

MIT — kaydzer0305-png
